# Memory Test Angka & Huruf

Website latihan memory test sederhana untuk GitHub Pages.

## Cara upload
1. Buat repository baru di GitHub, misalnya `memory-test`.
2. Upload `index.html` ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu **Save**.
6. Tunggu beberapa menit. Website akan tersedia di alamat GitHub Pages repository kamu.
